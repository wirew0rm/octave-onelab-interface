////////////////////////////////////////////////////////////////////////////////
// Onelab interface for octave. Exposes all necessary calls from the C++      //
// bindings to octave.                                                        //
// Alexander Krimm <alex@wirew0rm.de>, TEMF TU-Darmstadt, 2014                //
////////////////////////////////////////////////////////////////////////////////
// PKG_ADD: ollib = which("onelab.oct");

#include <gmsh/onelab.h>
#include <stdio.h>
#include <iostream>
#include <oct.h>
#include <octave/ov-struct.h>

#ifndef DEFCONST
#define DEFCONST(name, defn, doc) DEFCONST_INTERNAL(name, defn, doc)
#endif

onelab::remoteNetworkClient *c = NULL;

// PKG_ADD: autoload("ol_client", ollib);
// TODO: Add PKG_DEL directives
DEFUN_DLD (ol_client, args, ,
		           "create a client that connects to the server")
{
	int nargin = args.length();
	if (nargin != 2) 
		error("call ol_client with solver name and server adress");
	else {
		std::string name, address;
		name = args(0).string_value();
		address = args(1).string_value();

		if (c != NULL) delete c;
		c = new onelab::remoteNetworkClient(name, address);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_disconnect", ollib);
DEFUN_DLD (ol_disconnect, args, ,
		           "disconnect from the server and free the resources")
{
	if (c != NULL) {
		delete c;
		c = NULL;
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_getName", ollib);
DEFUN_DLD (ol_getName, args, ,
		           "get client name")
{
	int nargin = args.length();
	if (nargin != 0) 
		error("getName has no arguments");
	else {
		std::string name;
		name = c->getName();
		return octave_value_list(name);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_setId", ollib);
DEFUN_DLD (ol_setId, args, ,
		           "set client id")
{
	int nargin = args.length();
	if (nargin != 1) 
		error("setID needs argument id");
	else {
		int id = args(0).int_value();
		c->setId(id);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_getId", ollib);
DEFUN_DLD (ol_getId, args, ,
		           "get client id")
{
	int nargin = args.length();
	if (nargin != 0) 
		error("getId has no arguments");
	else {
		int id;
		id = c->getId();
		return octave_value_list(id);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_setIndex", ollib);
DEFUN_DLD (ol_setIndex, args, ,
		           "set client index")
{
	int nargin = args.length();
	if (nargin != 1) 
		error("setIndex needs argument index");
	else {
		int index = args(0).int_value();
		c->setIndex(index);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_getIndex", ollib);
DEFUN_DLD (ol_getIndex, args, ,
		           "get client id")
{
	int nargin = args.length();
	if (nargin != 0) 
		error("getIndex has no arguments");
	else {
		int index;
		index = c->getIndex();
		return octave_value_list(index);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_run", ollib);
DEFUN_DLD (ol_run, args, ,
		           "run client")
{
	int nargin = args.length();
	if (nargin != 0) 
		error("run has no arguments");
	else {
		return octave_value_list(c->run());
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_isNetworkClient", ollib);
DEFUN_DLD (ol_isNetworkClient, args, ,
		           "check if client is network client")
{
	int nargin = args.length();
	if (nargin != 0) 
		error("isNetworkClient has no arguments");
	else {
		return octave_value_list(c->isNetworkClient());
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_kill", ollib);
DEFUN_DLD (ol_kill, args, ,
		           "kill client")
{
	int nargin = args.length();
	if (nargin != 0) 
		error("kill has no arguments");
	else {
		return octave_value_list(c->kill());
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_sendInfo", ollib);
DEFUN_DLD (ol_sendInfo, args, ,
		           "send info")
{
	int nargin = args.length();
	if (nargin != 1) 
		error("call ol_sendInfo with msg");
	else {
		std::string msg = args(0).string_value();
		c->sendInfo(msg);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_sendWarning", ollib);
DEFUN_DLD (ol_sendWarning, args, ,
		           "send Warning")
{
	int nargin = args.length();
	if (nargin != 1) 
		error("call ol_sendWarning with msg");
	else {
		std::string msg = args(0).string_value();
		c->sendWarning(msg);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_sendError", ollib);
DEFUN_DLD (ol_sendError, args, ,
		           "send error")
{
	int nargin = args.length();
	if (nargin != 1) 
		error("call ol_sendError with msg");
	else {
		std::string msg = args(0).string_value();
		c->sendError(msg);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_sendProgress", ollib);
DEFUN_DLD (ol_sendProgress, args, ,
		           "send progress")
{
	int nargin = args.length();
	if (nargin != 1) 
		error("call ol_sendProgress with msg");
	else {
		std::string msg = args(0).string_value();
		c->sendProgress(msg);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_sendMergeFileRequest", ollib);
DEFUN_DLD (ol_sendMergeFileRequest, args, ,
		           "send merge file request")
{
	int nargin = args.length();
	if (nargin != 1) 
		error("call ol_sendMergeFileRequest with msg");
	else {
		std::string msg = args(0).string_value();
		c->sendMergeFileRequest(msg);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_sendParseStringRequest", ollib);
DEFUN_DLD (ol_sendParseStringRequest, args, ,
		           "send parse string request")
{
	int nargin = args.length();
	if (nargin != 1) 
		error("call ol_sendParseStringRequest with msg");
	else {
		std::string msg = args(0).string_value();
		c->sendParseStringRequest(msg);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_sendVertexArray", ollib);
DEFUN_DLD (ol_sendVertexArray, args, ,
		           "send vertex array")
{
	int nargin = args.length();
	if (nargin != 1) 
		error("call ol_sendVertexArray with msg");
	else {
		std::string msg = args(0).string_value();
		c->sendVertexArray(msg);
	}
	return octave_value_list ();
}



// PKG_ADD: autoload("ol_setNumber", ollib);
DEFUN_DLD (ol_setNumber, args, ,
		           "create or update a number")
{
	int nargin = args.length();
	if (nargin != 4) 
		error("call ol_setNumber with name, value, label and helpstring");
	else {
		std::string name = args(0).string_value();
		double value = args(1).double_value();
		std::string label = args(2).string_value();
		std::string help = args(3).string_value();

		onelab::number n = onelab::number(name, value, label, help);
		c->set(n);
	}
	return octave_value_list ();
}


// PKG_ADD: autoload("ol_setString", ollib);
DEFUN_DLD (ol_setString, args, ,
		           "create or update a string")
{
	int nargin = args.length();
	if (nargin != 4) 
		error("call ol_setNumber with name, value, label and helpstring");
	else {
		std::string name = args(0).string_value();
		std::string value = args(1).string_value();
		std::string label = args(2).string_value();
		std::string help = args(3).string_value();

		onelab::string n = onelab::string(name, value, label, help);
		c->set(n);
	}
	return octave_value_list ();
}


octave_value_list ol2oct(std::vector<onelab::number> parameterlist){
	octave_value_list result;
	for (std::vector<onelab::number>::iterator i = parameterlist.begin(); i != parameterlist.end(); ++i){
		octave_scalar_map st;
		st.assign("value", i->getValue());
		result.append(st);
	}
	return result;
}

// PKG_ADD: autoload("ol_getNumber", ollib);
DEFUN_DLD (ol_getNumber, args, ,
		           "get a Number from onelab")
{
	int nargin = args.length();
	octave_value_list result;
	if (nargin != 1) 
		error("call ol_getNumber with name");
	else {
		std::vector<onelab::number> n;
		std::string name = args(0).string_value();
		c->get(n, name);
	 	result = ol2oct(n);
	}
	return result;
}


// PKG_ADD: autoload("ol_getString", ollib);
DEFUN_DLD (ol_getString, args, ,
		           "get a String from onelab")
{
	int nargin = args.length();
	if (nargin != 1) {
		error("call ol_getString with name");
		return octave_value_list ();
	}
	std::string name = args(0).string_value();

	std::vector<onelab::string> s;
	octave_value_list result;
	if (c->get(s, name)){
		for (std::vector<onelab::string>::iterator si = s.begin(); si != s.end(); ++si){
			octave_scalar_map st;
			st.assign("value", si->getValue());
			result.append(st);
		}
	}
	return result;
}




// PKG_ADD: autoload("ol_toString", ollib);
DEFUN_DLD (ol_toString, args, ,
		           "output all Parameters as strings")
{
	int nargin = args.length();
	if (nargin != 0) 
		error("toStrin has no arguments");
	else {
		octave_value_list result;
		std::vector<std::string> v = c->toChar();
		for (std::vector<std::string>::iterator vi = v.begin(); vi != v.end(); ++vi){
			result.append(*vi);
		}
		return result;
	}
	return octave_value_list ();
}



/* TODO: TESTCASES

%!test 
%! assert(1,1)

*/
